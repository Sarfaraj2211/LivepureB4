function myform(){
    var name=document.getElementById("name").Value;
    var emal=document.getElementById("emal").Value;
    var password=document.getElementById("pas").Value;
    var name=document.getElementById("sum").Value;
}